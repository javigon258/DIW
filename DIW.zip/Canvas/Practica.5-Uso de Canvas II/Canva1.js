{
  function cargarContextoCanva(idcontex) {
    let elemento = document.getElementById(idcontex);
    if (elemento && elemento.getContext) {
      let contexto = elemento.getContext("2d");
      if (contexto) {
        return contexto;
      }
    }
    return false;
  }

  let contexto;

  window.onload = function() {
    contexto = cargarContextoCanva("micanvas");
    if (contexto) {


     contexto.beginPath();
     contexto.arc(150,120,100,0,Math.PI*2,true); // Círculo externo
     contexto.moveTo(215,120);
     contexto.stroke();

     contexto.beginPath();
     contexto.arc(150,120,65,0,Math.PI,false);   // Boca (contra reloj)
     contexto.strokeStyle = "rgba(0,0,255, 0.8)";
     contexto.moveTo(165,125);
     contexto.stroke();

     contexto.beginPath();
     contexto.arc(150,125,15,0,Math.PI*2,true);  // Ojo izquierdo
     contexto.fillStyle = "rgba(0,255,0, 0.8)";
     contexto.moveTo(145,80);
     contexto.fill();
     contexto.stroke();

     contexto.beginPath();
     contexto.arc(120,80,25,0,Math.PI*2,true); 
     contexto.moveTo(205,80);
     contexto.arc(180,80,25,0,Math.PI*2,true);  // Ojo derecho
     contexto.stroke();

     radGrad = contexto.createLinearGradient(164, 140, 1, 160, 143, 8);
     radGrad.addColorStop(1, "rgba(0,0,255, 0.8)");
    }
  };
}
