{
  function cargarContextoCanva(idcontex) {
    let elemento = document.getElementById(idcontex);
    if (elemento && elemento.getContext) {
      let contexto = elemento.getContext("2d");
      if (contexto) {
        return contexto;
      }
    }
    return false;
  }

  let contexto;

  window.onload = function() {
    contexto = cargarContextoCanva("micanvas");
    if (contexto) {

      contexto.beginPath();
      let fondGrad = contexto.createLinearGradient(20, 230, 200, 250);
      fondGrad.addColorStop(0.2,"#000");
      fondGrad.addColorStop(1,"#f4f9a4");
      contexto.fillStyle = fondGrad; //lienzo reducido
      contexto.fillRect(10,10,200,300);
      contexto.stroke();

      contexto.beginPath();
           
      let rectGrad = contexto.createLinearGradient(55, 230, 55, 300);
      rectGrad.addColorStop(0.5,"#837165");
      rectGrad.addColorStop(1, "#fff");
      contexto.fillStyle = rectGrad;
      //contexto.fillStyle = "#837165"; //Suelo
      contexto.fillRect(10,230,200,80);
      contexto.stroke();

      contexto.beginPath();
      let curvaGrad = contexto.createRadialGradient(8, 230, 90, 150, 230, 90);
      contexto.arc(10,230,90,0,1.5 * Math.PI,true);   //Parte curva de la casa
      curvaGrad.addColorStop(0.5,"#7A736B");
      curvaGrad.addColorStop(1, "#fff");
      //contexto.fillStyle = "#7A736B";
      contexto.fillStyle = curvaGrad;
      contexto.lineTo(10,230);
      contexto.lineTo(100,230);
      contexto.fill();

      contexto.beginPath();

      let puertaGrad = contexto.createLinearGradient(0, 105, 25, 300);
      puertaGrad.addColorStop(0.5,"#7A736B");
      puertaGrad.addColorStop(1,"#fff");
      //contexto.fillStyle = "#7A736B"; //Puerta
      contexto.fillStyle = puertaGrad;
      contexto.fillRect(10,185,105,45);
      contexto.stroke(); 


      contexto.fillStyle = "black";
      contexto.beginPath();
      contexto.arc(70,80,20,0,2*Math.PI,false);// borde
      contexto.fill();

      contexto.beginPath();
      let colorGrad1 = contexto.createRadialGradient(60, 65, 75, 70, 105, 10);
      contexto.arc(70,80,20,0,2*Math.PI,false); // Sol blanco
      //contexto.fillStyle = "#fff";
      colorGrad1.addColorStop(0.5,"#000");
      colorGrad1.addColorStop(1, "#fff");
      contexto.fillStyle = colorGrad1;
      contexto.moveTo(215,120);
      contexto.fill();

      contexto.strokeStyle = "black";
      contexto.beginPath();
      contexto.arc(140,120,20,0,2*Math.PI,false);  //borde
      contexto.stroke();

      contexto.beginPath();
      let colorGrad = contexto.createRadialGradient(135, 120, 125, 143, 105, 10);
      contexto.arc(140,120,20,0,2*Math.PI,false); // Sol normal
      //116, 107, 1, 120, 110, 10
      colorGrad.addColorStop(0.5,"#fff");
      colorGrad.addColorStop(1, "#FFDE8C");
      contexto.fillStyle = colorGrad;
      //contexto.fillStyle = "#FFDE8C";
      contexto.lineWidth = 10;
      contexto.moveTo(215,120);
      contexto.fill();
    }
  };
}
