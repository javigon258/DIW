{
  function cargarContextoCanva(idcontex) {
    let elemento = document.getElementById(idcontex);
    if (elemento && elemento.getContext) {
      let contexto = elemento.getContext("2d");
      if (contexto) {
        return contexto;
      }
    }
    return false;
  }

  let contexto;

  window.onload = function() {
    contexto = cargarContextoCanva("micanvas");
    if (contexto) {

      let img = new Image();
      img.src = "bosque.jpg";
      img.onload = function(){
          contexto.drawImage(img, 0, 0); 
          contexto.drawImage(img, 10, 150, 350, 100); 
          contexto.drawImage(img, 10, 15, 350, 120, 200, 250, 400, 250); 
          contexto.beginPath();
      }  
    }
  };
}
