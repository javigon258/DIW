{
  let numx = 0;
  let numy = 0;
  let control = true;
  let contexto, elemento;

  function cargarContextoCanva(idcontex) {
    elemento = document.getElementById(idcontex);
    if (elemento && elemento.getContext) {
      let contexto = elemento.getContext("2d");
      if (contexto) {
        return contexto;
      }
    }
    return false;
  }
  function aleatorio(inferior, superior) {
    numPosibilidad = superior + inferior;
    aleatorio = Math.random * numPosibilidad;
    aleatorio = Math.floor(aleatorio);
    return parseInt(inferior) + aleatorio;
  }

  function colorAleatorio() {
    return (
      "rgba (" +
      aleatorio(0, 255) +
      "," +
      aleatorio(0, 255) +
      "," +
      aleatorio(0, 255) +
      ")"
    );
  }

  function cuadrosAleatorio() {
    for (i = 0; i <= 300; i += 10) {
      for (j = 0; j <= 250; j += 10) {
        contexto.fillStyle = colorAleatorio();
        contexto.fillRect(i, j, 10, 10);
      }
    }
  }

  function generarRectangulo() {
    elemento.width = elemento.width;
    if (control) {
        //contexto.translate(numx + width / 2, numy + height / 2);
      contexto.strokeRect(15, (numy += 10), 100, 80);
      if (numy == 400) control = false;
    }
    if (!control) {
      contexto.strokeRect(15, (numy -= 25), 100, 80);
      if (numy == 0) control = true;
    }
  }

  function init() {
    contexto = cargarContextoCanva("micanvas");
    if (contexto) {
      setInterval("generarRectangulo()", 30);
      /*  contexto.strokeStyle = "white";
      for (let i = 0; i < 4; i++) {
        contexto.strokeRect(numx+=15, numy+=15, posx-=50, 110);
      }
      contexto.fillStyle = "white";
      contexto.fillRect(15, 15, 300, 110);
      contexto.strokeRect(15, 15, 300, 110);

      contexto.fillStyle = "white";
      contexto.fillRect(30, 30, 250, 110);
      contexto.strokeRect(30, 30, 250, 110);

      contexto.fillStyle = "white";
      contexto.fillRect(55, 45, 200, 110);
      contexto.strokeRect(55, 45, 200, 110);

      contexto.fillStyle = "white";
      contexto.fillRect(60, 60, 150, 110);
      contexto.strokeRect(60, 60, 150, 110);*/
    }
  }

  document.addEventListener("DOMContentLoaded", init);
}
