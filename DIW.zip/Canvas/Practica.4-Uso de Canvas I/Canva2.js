{
  let numx = 0;
  let numy = 0;
  let controly = true,
    controlx = true;
  let contexto, elemento;

  function cargarContextoCanva(idcontex) {
    elemento = document.getElementById(idcontex);
    if (elemento && elemento.getContext) {
      let contexto = elemento.getContext("2d");
      if (contexto) {
        return contexto;
      }
    }
    return false;
  }
  function aleatorio(inferior, superior) {
    numPosibilidad = superior + inferior;
    aleatorio = Math.random * numPosibilidad;
    aleatorio = Math.floor(aleatorio);
    return parseInt(inferior) + aleatorio;
  }

  function colorAleatorio() {
    return (
      "rgba (" +
      aleatorio(0, 255) +
      "," +
      aleatorio(0, 255) +
      "," +
      aleatorio(0, 255) +
      ")"
    );
  }

  function cuadrosAleatorio() {
    for (i = 0; i <= 300; i += 10) {
      for (j = 0; j <= 250; j += 10) {
        contexto.fillStyle = colorAleatorio();
        contexto.fillRect(i, j, 10, 10);
      }
    }
  }

function generarRectangulo2() {
    elemento.width = elemento.width;
    if (controlx && controly) {
      contexto.strokeRect((numx += 10), 10, 100, 80);
      contexto.strokeRect(10, (numy += 10), 100, 80);
      contexto.strokeRect((numx += 10), (numy += 10), 100, 80);
      if (numy == 400) controly = false;
      if (numx == 400) controlx = false;
    }
    if (!controlx && !controly) {
      contexto.strokeRect((numx -= 10), 10, 100, 80);
      contexto.strokeRect(10, (numy -= 10), 100, 80);
      contexto.strokeRect((numx -= 10), (numy -= 10), 100, 80);
      if (numy == 0) {
        //contexto.fillRect(50, 50, 100, 80);
        controly = true;
      }
      if (numx == 0) {
        //contexto.fillRect(50, 50, 100, 80);
        controlx = true;
      }
    }
  }

  function init() {
    contexto = cargarContextoCanva("micanvas");
    if (contexto) {
      setInterval("generarRectangulo2()",100);

    }
  }

  document.addEventListener("DOMContentLoaded", init);
}
