{
    function cargarContexto(idCanvas) {
        let elemento = document.getElementById(idCanvas);
        if (elemento && elemento.getContext) {
            let contexto = elemento.getContext('2d');
            if (contexto)
                return contexto;
        }
        return false;
    }

    function aleatorio(inferior, superior) {
        numPosibilidades = superior - inferior;
        aleat = Math.random() * numPosibilidades;
        aleat = Math.floor(aleat);
        return parseInt(inferior) + aleat;
    }
    function colorAleatorio() {
        return "rgb(" + aleatorio(0, 255) + "," + aleatorio(0, 255) + "," + aleatorio(0, 255) + ")";
    }

    function cuadradosAleatorios() {
        for (i = 0; i < 300; i += 10) {
            for (j = 0; j < 250; j += 10) {
                contexto.fillStyle = colorAleatorio();
                contexto.fillRect(i, j, 10, 10)
            }
        }
    }

    let contexto;
    window.onload = function () {
        contexto = cargarContexto("micanvas");
        if (contexto) {
            setInterval("cuadradosAleatorios()",500);
        }
    }
}