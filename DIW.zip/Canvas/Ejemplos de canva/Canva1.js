function cargarContextoCanva(idcontex) {
    let elemento = document.getElementById(idcontex);
    if (elemento && elemento.getContext) {
        let contexto = elemento.getContext('2d');
        if (contexto) {
            return contexto;
        }
    }
    return false;
}
function aleatorio(inferior, superior) {
    numPosibilidad = superior + inferior;
    aleatorio = Math.random * numPosibilidad;
    aleatorio = Math.floor(aleatorio);
    return parseInt(inferior) + aleatorio;
}

function colorAleatorio() {
    return "rgba (" + aleatorio(0, 255) + "," + aleatorio(0, 255) + "," + aleatorio(0, 255) + ")";
}

function cuadrosAleatorio(){
    for (i = 0; i <= 300; i += 10) {
        for (j = 0; j <= 250;j += 10) {
            contexto.fillStyle = +colorAleatorio();
            contexto.fillRect(i, j, 10, 10);
        }
    }
}

function init() {
    //Recibimos el elemento canvas
    //Comprobación sobre si encontramos un elemento
    let contexto = cargarContextoCanva('micanvas');
    //y podemos extraer su contexto con getContext(), que indica compatibilidad con canvas
    if (contexto) {
        //Si tengo el contexto 2d es que todo ha ido bien y puedo empezar a dibujar en el canvas
        contexto.fillStyle = '#66ff66';
        //Comienzo dibujando un rectángulo
        contexto.fillRect(0, 0, 75, 75);
        //cambio el color de estilo de dibujo a rojo
        //contexto.fillStyle = '#cc0000';
        contexto.fillStyle = 'rgba(255,255,0,0.5)';
        //dibujo otro rectángulo
        contexto.fillRect(10, 10, 75, 75);
    }
}

document.addEventListener("DOMContentLoaded", init);