{
    function cargarContextoCanva(idcontex) {
        let elemento = document.getElementById(idcontex);
        if (elemento && elemento.getContext) {
            let contexto = elemento.getContext('2d');
            if (contexto) {
                return contexto;
            }
        }
        return false;
    }

    let contexto;

    window.onload = function () {
        contexto = cargarContextoCanva('micanvas');
        if (contexto) {
            contexto.beginPath();
            contexto.arc(75,75,60,Math.PI,Math.PI*0.5,false);
            contexto.arc(75,75,45,Math.PI*0.5,Math.PI,false);

            contexto.fill();
            
            contexto.beginPath();
            contexto.fillStyle = 'orange';
            contexto.arc(75,75,15,0,Math.PI*2,false);
            contexto.fill();
        }
    }
}