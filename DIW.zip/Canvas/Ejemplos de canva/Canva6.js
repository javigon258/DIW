{
  function cargarContextoCanva(idcontex) {
    let elemento = document.getElementById(idcontex);
    if (elemento && elemento.getContext) {
      let contexto = elemento.getContext("2d");
      if (contexto) {
        return contexto;
      }
    }
    return false;
  }

  let contexto;

  window.onload = function() {
    contexto = cargarContextoCanva("micanvas");
    if (contexto) {
      contexto.fillStyle = "rgb(255,0,0)";
      contexto.fillRect(0, 0, 300, 200);
      contexto.strokeRect(0, 0, 300, 200);

      contexto.fillStyle = "white";
      contexto.fillRect(10, 60, 280, 130);
      contexto.strokeStyle = "rga(120, 120, 120)";
      contexto.strokeRect(10, 60, 280, 130);

      contexto.font = "bold 1.5em sans-serif";
      contexto.fillText("Hola, es mi nombre:", 20, 40);
      contexto.fillStyle = "black";
      contexto.textAlign = "center";
      contexto.font = "bold 70px Verdana";
      contexto.fillText("Javier", 150, 150);
    }
  };
}
