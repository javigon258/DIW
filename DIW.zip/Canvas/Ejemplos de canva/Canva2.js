{
    function cargarContextoCanva(idcontex) {
        let elemento = document.getElementById(idcontex);
        if (elemento && elemento.getContext) {
            let contexto = elemento.getContext('2d');
            if (contexto) {
                return contexto;
            }
        }
        return false;
    }

    let contexto;

    window.onload = function () {
        contexto = cargarContextoCanva('micanvas');
        if (contexto) {
            contexto.fillStyle = "#FF0000";
            contexto.beginPath();
            contexto.moveTo(50, 5);
            contexto.lineTo(75, 65);
            contexto.lineTo(50, 125);
            contexto.lineTo(25, 65);
            contexto.fill();

            contexto.fillStyle = "#FF0000";
            contexto.beginPath();
            contexto.moveTo(125, 5);
            contexto.lineTo(150, 65);
            contexto.lineTo(125, 125);
            contexto.lineTo(100, 65);
            contexto.fill();
        }
    }
}