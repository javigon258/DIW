{
    function cargarContextoCanva(idcontex) {
        let elemento = document.getElementById(idcontex);
        if (elemento && elemento.getContext) {
            let contexto = elemento.getContext('2d');
            if (contexto) {
                return contexto;
            }
        }
        return false;
    }

    let contexto;

    window.onload = function () {
        contexto = cargarContextoCanva('micanvas');
        if (contexto) {
            contexto.beginPath();
            contexto.moveTo(0,10);
            for (let i = 0; i <= 440; i+=11) {
               if((i%2) != 0)
                   contexto.lineTo(i+11,i);
               else
                   contexto.lineTo(i,i+11);
               
            }
            contexto.lineTo(1,451);
            contexto.closePath();
            contexto.stroke(); // stroke(), Relleno solo el borde
        }
    }
}